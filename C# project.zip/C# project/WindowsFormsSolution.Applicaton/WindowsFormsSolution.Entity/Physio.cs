﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsSolution.Entity
{
    public class Physio
    {
        public string playerid { get; set; }
        public string name { get; set; }
        public string injury { get; set; }
        public string fitness { get; set; }

        public string needs { get; set; }
    }
}
